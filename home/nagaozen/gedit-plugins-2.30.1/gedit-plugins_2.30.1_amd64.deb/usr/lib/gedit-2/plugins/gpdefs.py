# -*- coding: utf-8 -*-

VERSION = "2.30.0"
PACKAGE = "gedit-plugins"
PACKAGE_STRING = "gedit-plugins 2.30.0"
GETTEXT_PACKAGE = "gedit-plugins"
GP_LOCALEDIR = "/usr/share/locale"
